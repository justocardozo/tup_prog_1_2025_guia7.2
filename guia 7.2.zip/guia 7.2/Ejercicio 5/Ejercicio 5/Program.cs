﻿int numero;
int menor;
int posicion;
Console.WriteLine("Ingrese un numero");
numero = int.Parse(Console.ReadLine());
menor = numero;
posicion = 1;
Console.WriteLine("Ingrese otro numero:");
numero = int.Parse(Console.ReadLine());
if (numero < menor)
{
    menor= numero;
    posicion = 2;
}
Console.WriteLine("Ingrese otro numero:");
numero = int.Parse(Console.ReadLine());
if (numero < menor)
{
    menor = numero;
    posicion = 3;
}
Console.WriteLine("Ingrese otro numero:");
numero = int.Parse(Console.ReadLine());
if (numero < menor)
{
    menor = numero;
    posicion = 4;
}
Console.WriteLine("Ingrese otro numero:");
numero = int.Parse(Console.ReadLine());
if (numero < menor)
{
    menor = numero;
    posicion = 5;
}
Console.WriteLine("El menor numero ingresado fue en la posicion: " + posicion);