﻿int n1;
string a1;
int n2;
string a2;
int n3;
string a3;
Console.WriteLine("Ingrese el nombre del primer alumno");
a1 = Console.ReadLine();
Console.WriteLine("Ingrese el numero de libreta del primer alumno");
n1 = int.Parse(Console.ReadLine());
Console.WriteLine("Ingrese el nombre del segundo alumno");
a2 = Console.ReadLine();
Console.WriteLine("Ingrese el numero de libreta del segundo alumno:");
n2 = int.Parse(Console.ReadLine());
Console.WriteLine("Ingrese el nombre del tercer alumno");
a3 = Console.ReadLine();
Console.WriteLine("Ingrese el numero de libreta del tercer alumno:");
n3 = int.Parse(Console.ReadLine());

if (n1 <= n2 && n2 <= n3)
{
    Console.WriteLine("Numero de libreta: " + n1 + "| Nombre del alumno: " + a1);
    Console.WriteLine("Numero de libreta: " + n2 + "| Nombre del alumno: " + a2);
    Console.WriteLine("Numero de libreta: " + n3 + "| Nombre del alumno: " + a3);
}
else if (n2 <= n3 && n3 <= n1)
{
    Console.WriteLine("Numero de libreta: " + n2 + "| Nombre del alumno: " + a2);
    Console.WriteLine("Numero de libreta: " + n3 + "| Nombre del alumno: " + a3);
    Console.WriteLine("Numero de libreta: " + n1 + "| Nombre del alumno: " + a1);
}
else if (n3 <= n2 && n2 <= n1)
{
    Console.WriteLine("Numero de libreta: " + n3 + "| Nombre del alumno: " + a3);
    Console.WriteLine("Numero de libreta: " + n2 + "| Nombre del alumno: " + a2);
    Console.WriteLine("Numero de libreta: " + n1 + "| Nombre del alumno: " + a1);

}
else if (n1 <= n3 && n3 <= n2)
{
    Console.WriteLine("Numero de libreta: " + n1 + "| Nombre del alumno: " + a1);
    Console.WriteLine("Numero de libreta: " + n3 + "| Nombre del alumno: " + a3);
    Console.WriteLine("Numero de libreta: " + n2 + "| Nombre del alumno: " + a2);

}
else if (n2 <= n1 && n1 <= n3)
{
    Console.WriteLine("Numero de libreta: " + n2 + "| Nombre del alumno: " + a2);
    Console.WriteLine("Numero de libreta: " + n1 + "| Nombre del alumno: " + a1);
    Console.WriteLine("Numero de libreta: " + n3 + "| Nombre del alumno: " + a3);

}
else if (n3 <= n1 && n3 <= n2)
{
    Console.WriteLine("Numero de libreta: " + n3 + "| Nombre del alumno: " + a3);
    Console.WriteLine("Numero de libreta: " + n1 + "| Nombre del alumno: " + a1);
    Console.WriteLine("Numero de libreta: " + n2 + "| Nombre del alumno: " + a2);

}