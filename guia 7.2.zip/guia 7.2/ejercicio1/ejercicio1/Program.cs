﻿float n1;
float n2;
float n3;
float division;
float notafinal;
Console.WriteLine("Ingresa la primera nota: ");
n1 = float.Parse(Console.ReadLine());
Console.WriteLine("Ingresa la segunda nota: ");
n2 = float.Parse(Console.ReadLine());
Console.WriteLine("Ingresa la tercera nota: ");
n3 = float.Parse(Console.ReadLine());
division = (n1 + n2 + n3) / 3;
notafinal = division;
if  (notafinal >= 7)
{
    Console.WriteLine("La nota es " + notafinal + " Por lo tanto no rinde final");
}
if (notafinal <= 6)
{
 Console.WriteLine("La nota es " + notafinal + " Por lo tanto rinde final");
}