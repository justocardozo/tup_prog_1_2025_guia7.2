﻿string n1;
string n2;
int set1n1;
int set1n2;
int set2n1;
int set2n2;
int set3n1;
int set3n2;
int victorian1 = 0;
int victorian2 = 0;
Console.WriteLine("Ingrese el nombre del primer jugador:" );
n1 = Console.ReadLine();
Console.WriteLine("Ingrese ingrese el puntaje del primer set: ");
set1n1 = int.Parse(Console.ReadLine());
Console.WriteLine("Ingrese el nombre del segundo jugador:" );
n2 = Console.ReadLine();
Console.WriteLine("Ingrese ingrese el puntaje del primer set: ");
set1n2 = int.Parse(Console.ReadLine());
if (set1n1 > set1n2)
{
    victorian1++;
}
else if (set1n2 > set1n1)
{
    victorian2++;
}
Console.WriteLine($"Ingrese el puntaje del segundo set del jugador {n1}:");
set2n1 = int.Parse(Console.ReadLine());
Console.WriteLine($"Ingrese el puntaje del segundo set del jugador {n2}:");
set2n2 = int.Parse(Console.ReadLine());
if (set2n1 > set2n2)
{
    victorian1++;

}
else if (set2n2 > set2n1)
{
    victorian2++;

}
Console.WriteLine($"Ingrese el puntaje del tercer set del jugador {n1}:");
set3n1 = int.Parse(Console.ReadLine());
Console.WriteLine($"Ingrese el puntaje del tercer set del jugador {n2}:");
set3n2 = int.Parse(Console.ReadLine());
if (set3n1 > set3n2)
{
    victorian1++;

}
else if (set3n2 > set3n1)
{
    victorian2++;

}
if (victorian1 > victorian2)
{
    Console.WriteLine($"¡El jugador {n1} a ganado el partido!");
}
else if (victorian2 > victorian1)
{
    Console.WriteLine($"¡El jugador {n2} a ganado el partido!");
}
