﻿using System.Xml.Schema;

int numero;
Console.WriteLine("Ingrese un numero:");
numero = int.Parse(Console.ReadLine());
if (numero > 0)
{
    Console.WriteLine("Es Positivo");
}
if (numero < 0)
{
    Console.WriteLine("Es negativo");
}
if  (numero == 0)
{
    Console.WriteLine("es 0");
}